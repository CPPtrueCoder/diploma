clc; clear; format compact
t = 0:0.1:10;
R1 = dsolve('D2y+Dy-2*y = cos(t) - 3*sin(t)')
R2 = dsolve('D2y+Dy-2*y = cos(t) - 3*sin(t),y(0)=1,Dy(0)=2')
y = exp(t) + sin(t);
plot(t,y,'b');
grid on
legend('y(t)')
xlabel('t')
ylabel('y')