function dydt = diffs(t,y)
% y(1) -> y(x)
% y(2) -> y'(x)
% dydt(1) -> y'(x)
% dydt(2) -> y''(x)
%tspan = [1 10];
%y0 = [1 2];
%[T,Y]=ode45('Lab4Modelsp2',tspan,y0);
dydt = zeros(2,1);
dydt(1) = y(2);
dydt(2) = -y(2) + 2*y(1) + cos(t) - 3*sin(t);
end