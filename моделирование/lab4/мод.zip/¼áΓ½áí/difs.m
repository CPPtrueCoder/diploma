function F = difs(t,X)
F = [X(2); -X(2) + 2*X(1) + cos(t) - 3*sin(t)];
end