clc;clear;format compact;
X = dlmread('xklass.txt');
 
k = 4;
startPositions =dlmread('xklasspo4centers.txt'); 
for j=1:1:4
for i=1:1:27
    Vidstan(i,j)=sqrt(sum((X(i,:)-startPositions(j,:)).^2));
    end
end
[y,I] = min(Vidstan');
X1=X;
X1(:,26)=I';

for j=1:1:4
for i=1:1:25
    for ij=1:1:27
        if(X1(i,26)==1)
        NewstartPositions(1,i)=sum(X1(ij,i));
        end
        if(X1(i,26)==2)
        NewstartPositions(2,i)=sum(X1(ij,i));
        end
        if(X1(i,26)==3)
        NewstartPositions(3,i)=sum(X1(ij,i));
        end
        if(X1(i,26)==4)
        NewstartPositions(4,i)=sum(X1(ij,i));
        end
end
end
end

 
