clc;clear; format compact;
x=[1 1.4 1.8  2.2 2.6 3 3.4 3.8 4.2 4.6 5 5.4];
nx=[5 12 18 22 36 24 19 15 11 9 2];
n=sum(nx)
alpha=0.01;
Mx=0;
Dx=0;
k=8;
chienabl=0;
    for i=1:1:length(nx)
        M=(((x(i)+x(i+1))/2)*nx(i))/n;
        Mx=Mx+M;
    end
    for i=1:1:length(nx)
        D=(((((x(i)+x(i+1))/2)-Mx)^2)*nx(i))/n;
        Dx=Dx+D;  
    end   
Mx
Dx
Gx=sqrt(Dx)
for i=1:1:length(nx)
    P(i)=normcdf(x(i+1),Mx,Gx) - normcdf(x(i),Mx,Gx);
end
for i=1:1:length(nx)
    L=((nx(i)-n*P(i))^2)/(n*P(i));
    chienabl=chienabl+L;
end
chienabl
chiekrit = chi2inv(1-alpha, k)
if chienabl<chiekrit
fprintf('H0 � ���� ������������� �����������\n')
end
