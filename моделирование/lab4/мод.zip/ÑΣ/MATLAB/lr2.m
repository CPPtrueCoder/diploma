clc;clear;format compact;
Y=dlmread('y.txt');
X=dlmread('x.txt');
sx = std(X); 
mx = mean(X);
sy = std(Y); 
my = mean(Y);
for i=1:1:8
X1(:,i)=(X(:,i)-mx(i))/(sx(i));
end
Y1=(Y-my)/sy;
X1transp=X1';
X1transpUmnozhX1=X1transp*X1;
X1transpUmnozhX1obr=inv(X1transpUmnozhX1);
X1transpumnozhY1=X1transp*Y1;
X1transpUmnozhX1obrumnozhX1transpumnozhY1=X1transpUmnozhX1obr*X1transpumnozhY1;
Umnozh=X1*X1transpUmnozhX1obrumnozhX1transpumnozhY1;
for i=1:1:24
    R(i,1)=((Y1(i)-Umnozh(i))^2)/24;
end
Rkv=vpa(1-sum(R));
R=X1transpUmnozhX1/24;
[U,L]=eig(R)
z1=X1*U(:,7:8);
Xvost1=z1*(U(:,7:8))';
Razn1=0;
for i=1:1:24
    for j=1:1:8
        X1minusxvost1=(X1(i,j)-Xvost1(i,j))^2;
        Razn1=Razn1+X1minusxvost1;
    end
end
Razn1

Razn2=0;
z2=X1*U(:,6:8);
Xvost2=z2*(U(:,6:8))';
Razn2=0;
for i=1:1:24
    for j=1:1:8
        X1minusxvost2=(X1(i,j)-Xvost2(i,j))^2;
        Razn2=Razn2+X1minusxvost2;
    end
end
Razn2

Razn3=0;
z3=X1*U(:,5:8);
Xvost3=z3*(U(:,5:8))';
Razn3=0;
for i=1:1:24
    for j=1:1:8
        X1minusxvost3=(X1(i,j)-Xvost3(i,j))^2;
        Razn3=Razn3+X1minusxvost3;
    end
end
Razn3

Razn4=0;
z4=X1*U(:,4:8);
Xvost4=z4*(U(:,4:8))';
Razn4=0;
for i=1:1:24
    for j=1:1:8
        X1minusxvost4=(X1(i,j)-Xvost4(i,j))^2;
        Razn4=Razn4+X1minusxvost4;
    end
end
Razn4

Razn5=0;
z5=X1*U(:,3:8);
Xvost5=z5*(U(:,3:8))';
Razn5=0;
for i=1:1:24
    for j=1:1:8
        X1minusxvost5=(X1(i,j)-Xvost5(i,j))^2;
        Razn5=Razn5+X1minusxvost5;
    end
end
Razn5

Razn6=0;
z6=X1*U(:,2:8);
Xvost6=z6*(U(:,2:8))';
Razn6=0;
for i=1:1:24
    for j=1:1:8
        X1minusxvost6=(X1(i,j)-Xvost6(i,j))^2;
        Razn6=Razn6+X1minusxvost6;
    end
end
Razn6

Razn7=0;
z7=X1*U(:,1:8);
Xvost7=z7*(U(:,1:8))';
Razn7=0;
for i=1:1:24
    for j=1:1:8
        X1minusxvost7=(X1(i,j)-Xvost7(i,j))^2;
        Razn7=Razn7+X1minusxvost7;
    end
end
Razn7

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
n=8;
e1=[1/sqrt(n); 1/sqrt(n); 1/sqrt(n); 1/sqrt(n); 1/sqrt(n); 1/sqrt(n); 1/sqrt(n); 1/sqrt(n)];

Z1=X1*e1;
for j=1:1:8
for i=1:1:24
      ch1(i,j)=(X1(i,j)*Z1(i,:));
      zn1(i)=Z1(i)*Z1(i);
end
    CH1(:,j)=sum(ch1(:,j));
    ZN1=sum(zn1);
end

for j=1:1:8
     e2(j)=CH1(j)/ZN1;
end
e2dl=sqrt(sum(e2.*e2));
e2=(e2./e2dl)'



Z2=X1*e2;
for j=1:1:8
for i=1:1:24
      ch2(i,j)=(X1(i,j)*Z2(i,:));
      zn2(i)=Z2(i)*Z2(i);
end
    CH2(:,j)=sum(ch2(:,j));
    ZN2=sum(zn2);
end

for j=1:1:8
     e3(j)=CH2(j)/ZN2;
end
e3dl=sqrt(sum(e3.*e3));
e3=(e3./e3dl)'

Z3=X1*e3;
for j=1:1:8
for i=1:1:24
      ch3(i,j)=(X1(i,j)*Z3(i,:));
      zn3(i)=Z3(i)*Z3(i);
end
    CH3(:,j)=sum(ch3(:,j));
    ZN3=sum(zn3);
end

for j=1:1:8
     e4(j)=CH3(j)/ZN3;
end
e4dl=sqrt(sum(e4.*e4));
e4=(e4./e4dl)'


Z4=X1*e4;
for j=1:1:8
for i=1:1:24
      ch4(i,j)=(X1(i,j)*Z4(i));
      zn4(i)=Z4(i)*Z4(i);
end
    CH4(:,j)=sum(ch4(:,j));
    ZN4=sum(zn4);
end

for j=1:1:8
     e5(j)=CH4(j)/ZN4;
end
e5dl=sqrt(sum(e5.*e5));
e5=(e5./e5dl)'


Z5=X1*e5;
for j=1:1:8
for i=1:1:24
      ch5(i,j)=(X1(i,j)*Z5(i));
      zn5(i)=Z5(i)*Z5(i);
end
    CH5(:,j)=sum(ch5(:,j));
    ZN5=sum(zn5);
end

for j=1:1:8
     e6(j)=CH5(j)/ZN5;
end
e6dl=sqrt(sum(e6.*e6));
e6=(e6./e6dl)'



Z6=X1*e6;
for j=1:1:8
for i=1:1:24
      ch6(i,j)=(X1(i,j)*Z6(i));
      zn6(i)=Z6(i)*Z6(i);
end
    CH6(:,j)=sum(ch6(:,j));
    ZN6=sum(zn6);
end

for j=1:1:8
     e7(j)=CH6(j)/ZN6;
end
e7dl=sqrt(sum(e7.*e7));
e7=(e7./e7dl)'


Z7=X1*e7;
for j=1:1:8
for i=1:1:24
      ch7(i,j)=(X1(i,j)*Z7(i));
      zn7(i)=Z7(i)*Z7(i);
end
    CH7(:,j)=sum(ch7(:,j));
    ZN7=sum(zn7);
end

for j=1:1:8
     e8(j)=CH7(j)/ZN7;
end
e8dl=sqrt(sum(e8.*e8));
e8=(e8./e8dl)'