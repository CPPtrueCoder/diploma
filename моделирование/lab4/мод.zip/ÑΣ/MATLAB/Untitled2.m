clc; clear;format compact;
P=[0.9 0.1 0; 0.1 0.8 0.1; 0 0.2 0.8];
p0=[0.2 0.3 0.5];
p1=p0*P
p2=p1*P
p3=p2*P

A = [-0.1 0.1 0 ; 0 0.1 -0.2; 1 1 1];
b = [0; 0; 1];

rank(A)

A1 = A;
A2 = A;
A3 = A;

A1(:,1) = b;
A2(:,2) = b;
A3(:,3) = b;


x1 = det(A1) / det(A);
x2 = det(A2) / det(A);
x3 = det(A3) / det(A);

x=[x1;x2;x3]

