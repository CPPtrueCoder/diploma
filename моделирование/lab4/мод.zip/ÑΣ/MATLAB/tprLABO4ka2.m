clc;clear;format compact;
R=dlmread('r.txt');
R=R';
m=5;
d=6;
alpha=0.05;
for i=1:1:5
    r(i)=sum(R(i,:));
end
r=r'
rsredn=sum(r)/m

for i=1:1:m
    S(i)=(r(i)-rsredn)^2;
end
S=sum(S)
W=(12*S)/(d^2*(m^3-m))
XiKvNabl=(12*S)/(d*m*(m+1))


