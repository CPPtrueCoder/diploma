clc;clear;format compact;
X=[1 2 3 4 5 6 7 8 9 10];
Y=[2.2 2.5 2.8 4.6 5.5 7.4 8.6 11.1 14.3 18.2];
Mxy1=0;
Mxkv1=0;
Mykv1=0;
for i=1:1:10
    X1(i)=1/X(i);
end
Epsilumkv1=0;
for i=1:1:10
    z1=(X1(i)*Y(i))/10;
    Mxy1=Mxy1+z1;
end
Mx1=sum(X1)/10;
My1=sum(Y)/10;
for i=1:1:10
    Mkv1=(X1(i))^2;
    Mxkv1=Mxkv1+Mkv1;
end
Mxkv1=Mxkv1/10;
for i=1:1:10
    Mkvy1=(Y(i))^2;
    Mykv1=Mykv1+Mkvy1;
end
a1=(Mxy1-(Mx1*My1))/((Mxkv1)-(Mx1)^2)
b1=My1-a1*Mx1
for i=1:1:10
    Eps1=(Y(i)-(a1*X1(i)+b1))^2;
    Epsilumkv1=Epsilumkv1+Eps1;
end
Epsilumkv1


Mxy2=0;
Mxkv2=0;
Mykv2=0;
for i=1:1:10
    X2(i)=log(X(i));
end
Epsilumkv2=0;
for i=1:1:10
    z2=(X2(i)*Y(i))/10;
    Mxy2=Mxy2+z2;
end
Mx2=sum(X2)/10;
My2=sum(Y)/10;
for i=1:1:10
    Mkv2=(X2(i))^2;
    Mxkv2=Mxkv2+Mkv2;
end
Mxkv2=Mxkv2/10;
for i=1:1:10
    Mkvy2=(Y(i))^2;
    Mykv2=Mykv2+Mkvy2;
end
a2=(Mxy2-(Mx2*My2))/((Mxkv2)-(Mx2)^2)
b2=My2-a2*Mx2
for i=1:1:10
    Eps2=(Y(i)-(a2*X2(i)+b2))^2;
    Epsilumkv2=Epsilumkv2+Eps2;
end
Epsilumkv2


Mxy3=0;
Mxkv3=0;
Mykv3=0;
for i=1:1:10
    X3(i)=sqrt(X(i));
end
Epsilumkv3=0;
for i=1:1:10
    z3=(X3(i)*Y(i))/10;
    Mxy3=Mxy3+z3;
end
Mx3=sum(X3)/10;
My3=sum(Y)/10;
for i=1:1:10
    Mkv3=(X3(i))^2;
    Mxkv3=Mxkv3+Mkv3;
end
Mxkv3=Mxkv3/10;
for i=1:1:10
    Mkvy3=(Y(i))^2;
    Mykv3=Mykv3+Mkvy3;
end
a3=(Mxy3-(Mx3*My3))/((Mxkv3)-(Mx3)^2)
b3=My3-a3*Mx3
for i=1:1:10
    Eps3=(Y(i)-(a3*X3(i)+b3))^2;
    Epsilumkv3=Epsilumkv3+Eps3;
end
Epsilumkv3


Mxy4=0;
Mxkv4=0;
Mykv4=0;
for i=1:1:10
    X4(i)=(X(i))^2;
end
Epsilumkv4=0;
for i=1:1:10
    z4=(X4(i)*Y(i))/10;
    Mxy4=Mxy4+z4;
end
Mx4=sum(X4)/10;
My4=sum(Y)/10;
for i=1:1:10
    Mkv4=(X4(i))^2;
    Mxkv4=Mxkv4+Mkv4;
end
Mxkv4=Mxkv4/10;
for i=1:1:10
    Mkvy4=(Y(i))^2;
    Mykv4=Mykv4+Mkvy4;
end
a4=(Mxy4-(Mx4*My4))/((Mxkv4)-(Mx4)^2)
b4=My4-a4*Mx4
for i=1:1:10
    Eps4=(Y(i)-(a4*X4(i)+b4))^2;
    Epsilumkv4=Epsilumkv4+Eps4;
end
Epsilumkv4


Mxy5=0;
Mxkv5=0;
Mykv5=0;
for i=1:1:10
    X5(i)=(X(i))^3;
end
Epsilumkv5=0;
for i=1:1:10
    z5=(X5(i)*Y(i))/10;
    Mxy5=Mxy5+z5;
end
Mx5=sum(X5)/10;
My5=sum(Y)/10;
for i=1:1:10
    Mkv5=(X5(i))^2;
    Mxkv5=Mxkv5+Mkv5;
end
Mxkv5=Mxkv5/10;
for i=1:1:10
    Mkvy5=(Y(i))^2;
    Mykv5=Mykv5+Mkvy5;
end
a5=(Mxy5-(Mx5*My5))/((Mxkv5)-(Mx5)^2)
b5=My5-a5*Mx5
for i=1:1:10
    Eps5=(Y(i)-(a5*X5(i)+b5))^2;
    Epsilumkv5=Epsilumkv5+Eps5;
end
Epsilumkv5


Mxy6=0;
Mxkv6=0;
Mykv6=0;
for i=1:1:10
    Y6(i)=1/Y(i);
end
Epsilumkv6=0;
for i=1:1:10
    z6=(X(i)*Y6(i))/10;
    Mxy6=Mxy6+z6;
end
Mx6=sum(X)/10;
My6=sum(Y6)/10;
for i=1:1:10
    Mkv6=(X(i))^2;
    Mxkv6=Mxkv6+Mkv6;
end
Mxkv6=Mxkv6/10;
for i=1:1:10
    Mkvy6=(Y6(i))^2;
    Mykv6=Mykv6+Mkvy6;
end
a6=(Mxy6-(Mx6*My6))/((Mxkv6)-(Mx6)^2)
b6=My6-a6*Mx6
for i=1:1:10
    Eps6=(Y(i)-(a6*X(i)+b6))^2;
    Epsilumkv6=Epsilumkv6+Eps6;
end
Epsilumkv6


Mxy7=0;
Mxkv7=0;
Mykv7=0;
for i=1:1:10
    X7(i)=exp(-X(i));
end
for i=1:1:10
    Y7(i)=1/Y(i);
end
Epsilumkv7=0;
for i=1:1:10
    z7=(X7(i)*Y7(i))/10;
    Mxy7=Mxy7+z7;
end
Mx7=sum(X7)/10;
My7=sum(Y7)/10;
for i=1:1:10
    Mkv7=(X7(i))^2;
    Mxkv7=Mxkv7+Mkv7;
end
Mxkv7=Mxkv7/10;
for i=1:1:10
    Mkvy7=(Y7(i))^2;
    Mykv7=Mykv7+Mkvy7;
end
a7=(Mxy7-(Mx7*My7))/((Mxkv7)-(Mx7)^2)
b7=My7-a7*Mx7
for i=1:1:10
    Eps7=(Y(i)-(a7*X7(i)+b7))^2;
    Epsilumkv7=Epsilumkv7+Eps7;
end
Epsilumkv7


Mxy8=0;
Mxkv8=0;
Mykv8=0;
for i=1:1:10
    Y8(i)=log(Y(i));
end
Epsilumkv8=0;
for i=1:1:10
    z8=(X(i)*Y8(i))/10;
    Mxy8=Mxy8+z8;
end
Mx8=sum(X)/10;
My8=sum(Y8)/10;
for i=1:1:10
    Mkv8=(X(i))^2;
    Mxkv8=Mxkv8+Mkv8;
end
Mxkv8=Mxkv8/10;
for i=1:1:10
    Mkvy8=(Y8(i))^2;
    Mykv8=Mykv8+Mkvy8;
end
a8=(Mxy8-(Mx8*My8))/((Mxkv8)-(Mx8)^2)
b8=My8-a8*Mx8
for i=1:1:10
    Eps8=(Y(i)-(exp(a8)*X(i)+exp(b8)))^2;
    Epsilumkv8=Epsilumkv8+Eps8;
end
Epsilumkv8


Mxy9=0;
Mxkv9=0;
Mykv9=0;
for i=1:1:10
    X9(i)=1/X(i);
end
for i=1:1:10
    Y9(i)=log(Y(i));
end
Epsilumkv9=0;
for i=1:1:10
    z9=(X9(i)*Y9(i))/10;
    Mxy9=Mxy9+z9;
end
Mx9=sum(X9)/10;
My9=sum(Y9)/10;
for i=1:1:10
    Mkv9=(X9(i))^2;
    Mxkv9=Mxkv9+Mkv9;
end
Mxkv9=Mxkv9/10;
for i=1:1:10
    Mkvy9=(Y9(i))^2;
    Mykv9=Mykv9+Mkvy9;
end
a9=(Mxy9-(Mx9*My9))/((Mxkv9)-(Mx9)^2)
b9=My9-a9*Mx9
for i=1:1:10
    Eps9=(Y(i)-(a9*X9(i)+exp(b9)))^2;
    Epsilumkv9=Epsilumkv9+Eps9;
end
Epsilumkv9


Mxy10=0;
Mxkv10=0;
Mykv10=0;
for i=1:1:10
    X10(i)=X(i);
end
for i=1:1:10
    Y10(i)=log(Y(i));
end
Epsilumkv10=0;
for i=1:1:10
    z10=(X10(i)*Y10(i))/10;
    Mxy10=Mxy10+z10;
end
Mx10=sum(X10)/10;
My10=sum(Y10)/10;
for i=1:1:10
    Mkv10=(X10(i))^2;
    Mxkv10=Mxkv10+Mkv10;
end
Mxkv10=Mxkv10/10;
for i=1:1:10
    Mkvy10=(Y10(i))^2;
    Mykv10=Mykv10+Mkvy10;
end
a10=(Mxy10-(Mx10*My10))/((Mxkv10)-(Mx10)^2)
b10=My10-a10*Mx10
for i=1:1:10
    Eps10=(Y(i)-(a10*X10(i)+exp(b10)))^2;
    Epsilumkv10=Epsilumkv10+Eps10;
end
Epsilumkv10


Mxy11=0;
Mxkv11=0;
Mykv11=0;
for i=1:1:10
    X11(i)=X(i)*log(X(i));
end
for i=1:1:10
    Y11(i)=log(Y(i));
end
Epsilumkv11=0;
for i=1:1:10
    z11=(X11(i)*Y11(i))/10;
    Mxy11=Mxy11+z11;
end
Mx11=sum(X11)/10;
My11=sum(Y11)/10;
for i=1:1:10
    Mkv11=(X11(i))^2;
    Mxkv11=Mxkv11+Mkv11;
end
Mxkv11=Mxkv11/10;
for i=1:1:10
    Mkvy11=(Y11(i))^2;
    Mykv11=Mykv11+Mkvy11;
end
a11=(Mxy11-(Mx11*My11))/((Mxkv11)-(Mx11)^2)
b11=My11-a11*Mx11
for i=1:1:10
    Eps11=(Y(i)-(a11*X11(i)+exp(b11)))^2;
    Epsilumkv11=Epsilumkv11+Eps11;
end
Epsilumkv11