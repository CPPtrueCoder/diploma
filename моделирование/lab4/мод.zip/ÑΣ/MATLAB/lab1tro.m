clc; clear; format compact;
V = dlmread('data.txt');
Vt = V';
VtxV = Vt * V;
VtxVinv = inv(VtxV);
Vx = VtxVinv * Vt;
for i=1:1:length(V)
    y0(i,:) = 1;
end
w0 = Vx * y0;
proverka = V * w0;
count = 0;
for i=1:1:length(proverka)
    if proverka(i,:) > 0
        count = count + 1;
    end
end
if count == 20
    fprintf('Operation successfully completed.\n');
    v = V;
    v(:,3) = [];
    for i=((length(v)/2)+1):1:length(v)
        v(i,:) = v(i,:) * (-1);
    end
    plot(v(:,1),v(:,2),'o');
    hold on;
    x1= -5:1:5;
    x2 = (w0(1) * x1 + w0(3)) / (-w0(2));
    plot(x1,x2,'g');
    grid on;
else fprintf('Please check the data.\n');
end
det(VtxV)