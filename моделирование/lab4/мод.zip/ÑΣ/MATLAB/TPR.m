clc;clear;format compact;
R=[1 1 0 1 0; 1 1 1 1 0; 1 0 1 1 1; 0 1 1 1 1; 0 1 0 0 0]
