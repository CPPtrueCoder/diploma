X = dlmread('xklass.txt');
opts = statset('Display','final');
 
k = 4;
startPositions =dlmread('xklasspo4centers.txt'); % ��� �������� ��������� ������� kmeans
 
[idx,ctrs] = kmeans(X,k,'Distance','city','Options',opts,'Start',startPositions);
 
plot(X(idx==1,1),X(idx==1,2),'r.','MarkerSize',16)
hold on
plot(X(idx==2,1),X(idx==2,2),'b.','MarkerSize',16)
hold on
plot(X(idx==3,1),X(idx==3,2),'k.','MarkerSize',16)
hold on
plot(X(idx==4,1),X(idx==4,2),'m.','MarkerSize',16)
plot(ctrs(:,1),ctrs(:,2),'kx', 'MarkerSize',10,'LineWidth',1)
legend('Cluster 1','Cluster 2','Cluster 3','Cluster 4','Centroids', 'Location','NW')