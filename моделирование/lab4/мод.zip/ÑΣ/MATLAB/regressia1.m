clc;clear;format compact;
x=[0.531 0.524 0.541 0.550 0.559 0.620 0.632 0.672 0.682 0.689 0.692 0.694 0.698 0.690 0.710 0.720 0.725 0.730];
nx=length(x);
y=[0.620 0.580 0.640 0.650 0.670 0.680 0.695 0.699 0.710 0.715 0.725 0.781 0.790 0.795 0.800 0.810 0.850 0.860];
ny=length(y);
Rkv=0;
t=2.90;
Sumx=0;
Mx=sum(x)/nx
My=sum(y)/ny
Mxy=0;
Mxkv=0;
Mykv=0;
Epsilumkv=0;
for i=1:1:nx
    M=x(i)*y(i);
    Mxy=Mxy+M;
end
Mxy=Mxy/18
for i=1:1:nx
    Mkv=(x(i))^2;
    Mxkv=Mxkv+Mkv;
end
Mxkv=Mxkv/nx
for i=1:1:ny
    Mkvy=(y(i))^2;
    Mykv=Mykv+Mkvy;
end
Mykv=Mykv/ny
a=(Mxy-(Mx*My))/((Mxkv)-(Mx)^2)
b=My-a*Mx
for i=1:1:ny
    Epskv=(y(i)-(a*x(i)+b))^2
    Epsilumkv=Epsilumkv+Epskv;
end
Epsilumkv
for i=1:1:nx
    Summx=(x(i)-Mx)^2;
    Sumx=Sumx+Summx;
end
Sumx
rxy=(Mxy-(Mx*My))/(sqrt((Mxkv-(Mx)^2)*(Mykv-(My)^2)))
for i=1:1:nx
    deltay=Epsilumkv*t*sqrt((1/nx)+((x(i)-Mx)/Sumx))
end
deltay
for i=1:1:nx
    deltayprog=Epsilumkv*t*sqrt(1+(1/nx)+((x(i)-Mx)/Sumx))
end
deltayprog
for i=1:1:nx
    Rkv=1-(((sum(y(i)-(a*x(i)+b)))^2)/(sum(y(i)-Mx))^2)
end