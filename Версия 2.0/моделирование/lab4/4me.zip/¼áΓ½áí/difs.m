function F = difs(t,X)
F = [X(2); -X(1) + cos(3*t)];
end